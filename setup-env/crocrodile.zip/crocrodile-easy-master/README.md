# Crocrodile
## crocrodile-easy
The official repository of the Crocrodile chess engine. This repository is for release versions of Crocrodile.
### Setup
You need Python to install Crocrodile. Run the setup script : `python3 setup.py`
